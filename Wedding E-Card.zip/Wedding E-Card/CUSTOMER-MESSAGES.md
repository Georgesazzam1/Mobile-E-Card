# Customer messages (copy, paste, edit the [brackets])

The customer **never needs your Gmail password or login**.
Your business Gmail is only the address the RSVP emails come **from**.
What the couple gets from you: **their invitation link**, **their guest links**, and (for $120/$150) **a view-only link to their guest list**.

---

## 1. When a couple orders — what you need from them

> Hello [Name] 🤍 Thank you for choosing us!
> To prepare your invitation, please send me:
>
> 1. Your names as you want them written (e.g. Georges & Lina)
> 2. Wedding date and times (ceremony + party)
> 3. Church / venue names + Google Maps location for each
> 4. 1 main photo + 3 photos for the gallery (best quality you have)
> 5. RSVP deadline date
> 6. Your guest list: name + number of seats for each
> 7. **The email address(es) where you want to receive RSVP notifications** ($120 / $150)
> 8. WhatsApp number for RSVPs ($100 package)
> 9. A song you love, or I will choose a romantic one for you 🎶
>
> I'll send you a preview within [48 hours].

---

## 2. Preview for approval

> Here is your invitation preview 🤍
> [preview link]
> Tap the seal to open it. Please check names, dates, times and locations carefully,
> and tell me if you'd like anything changed. Once you approve, I'll prepare your guest links.

---

## 3. Delivery — $100 Essential

> Your invitation is ready! 🎉
>
> 💌 **Your guest links:** [attach guest-links.csv or paste the list]
> Each guest has their own link with their name on it. Just forward it on WhatsApp.
>
> ✅ Guests will confirm by WhatsApp on [number].
>
> Congratulations and thank you! — Signature by Georges Azzam

## 4. Delivery — $120 Signature / $150 Luxe

> Your invitation is ready! 🎉
>
> 💌 **Your guest links:** [attach guest-links.csv or paste the list]
> Each guest has their own link with their name and number of seats.
>
> 📋 **Your live guest list:** [Google Sheet link]
> The **Summary** tab shows who is coming, who declined and how many seats are left.
>
> 📧 Every time a guest replies, you'll receive an email from **[your business Gmail]**.
> Please check your spam folder for the first one and mark it **Not spam**.
>
> [$150 only] 💬 Wishes from your guests appear on your invitation automatically.
>
> Congratulations and thank you! — Signature by Georges Azzam

---

## 5. Reminder before the RSVP deadline (optional, sent by the couple)

> Dear [Guest], a gentle reminder to confirm your attendance before [date] 🤍
> Your invitation: [their personal link]
