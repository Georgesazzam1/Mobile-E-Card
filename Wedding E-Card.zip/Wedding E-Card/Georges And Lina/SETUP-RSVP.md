# RSVP setup — Google Sheet + email to the couple

Used for the **$120 Signature** and **$150 Luxe** packages.
(The **$100 Essential** package uses the WhatsApp button — skip this guide.)

```
Guest fills the RSVP form ──► Google Sheet (one per couple) ──► Email to the couple
                                     │
                                     └──► Wishes wall on the invitation ($150)
```

---

## Part A — One time only: your business account

1. Create a new Gmail account for the business, named after your brand
   (for example `<yourbrand>.invitations@gmail.com`). You create it yourself.
2. In Google Drive of that account, create a folder: **RSVP – Clients**.
3. Create the **master sheet** (you do this once and copy it for every couple):
   1. In the folder: **New → Google Sheets**. Name it **MASTER – RSVP template**.
   2. **Extensions → Apps Script**.
   3. Delete what is there, and paste everything from [`apps-script/Code.gs`](apps-script/Code.gs).
   4. Click **Save** (disk icon). Name the project "RSVP".

---

## Part B — For every new couple (≈ 5 minutes)

### 1. Copy the master sheet
- Open **MASTER – RSVP template** → **File → Make a copy**
- Name: **Georges & Lina – RSVP** (the script is copied with it)

### 2. Edit the couple's settings
- In the copy: **Extensions → Apps Script**
- At the top of the code, change:
  ```js
  coupleNames: "Georges & Lina",
  coupleEmails: "lina@gmail.com, georges@gmail.com",
  sendEmails: true,
  ```
- **Save**.

### 3. Run setup once
- In the toolbar, choose the function **setup** → click **Run**.
- Google asks for permission:
  **Review permissions → choose your business account → Advanced → Go to RSVP (unsafe) → Allow**.
  ("unsafe" only means Google has not reviewed your own private script. That is normal.)
- Go back to the sheet: you now have two tabs, **Summary** and **RSVPs**.

### 4. Publish it as a web app
- **Deploy → New deployment**
- Click the gear ⚙ → **Web app**
- Description: `Georges & Lina RSVP`
- **Execute as: Me**
- **Who has access: Anyone**
- **Deploy** → copy the **Web app URL** (it ends with `/exec`).

### 5. Connect the invitation
In the couple's invitation folder, open `config.js` and paste the URL:
```js
rsvpEndpoint: "https://script.google.com/macros/s/XXXXXXXX/exec",
```

### 6. Test before you deliver
1. Open the invitation with a test name: `...?to=Test Guest&seats=2`
2. Send an RSVP with a wish.
3. Check: a new row in **RSVPs** ✔ · email received ✔ · wish on the wall ($150) ✔
4. Delete the test row from the sheet.

### 7. Share with the couple
- Sheet → **Share** → add the couple's email → **Viewer** → Send.

---

## Good to know

| Question | Answer |
|---|---|
| A guest replies twice? | Their row is **updated** (matched by name), not duplicated. |
| Hide an unkind wish from the wall? | Untick **Show wish** in the sheet. |
| I changed the code later | **Deploy → Manage deployments → ✏ Edit → Version: New version → Deploy**. Otherwise the old code keeps running. The URL stays the same. |
| Email limit | Free Gmail ≈ 100 emails/day across all couples. Plenty to start; Google Workspace raises it. |
| Emails in spam? | Ask the couple to mark the first email **Not spam**. |
| Demo for Instagram / customers | Leave `rsvpEndpoint` empty — the form works without saving anything. |
