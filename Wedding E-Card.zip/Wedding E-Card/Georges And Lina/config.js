/* ==========================================================
   INVITATION SETTINGS — edit this file for every new couple
   ========================================================== */
window.INVITE = {
  /* 1 = Essential ($100) : photos, details, locations, music, WhatsApp RSVP
     2 = Signature ($120) : + RSVP form (email to couple), countdown
     3 = Luxe ($150)      : + guest wishes wall
     This is the PAID package = the maximum. ?pkg= in a link can only show
     the same or a lower package (handy for demos), never a higher one.    */
  package: 2,

  couple: {
    bride: "Georges",   // first name shown
    groom: "Lina",      // second name shown
    monogram: "G&L",
    hashtag: "#GeorgesAndLinaForever",
  },

  // ISO date-time in Lebanon time (UTC+3 in summer)
  date: "2025-08-23T17:30:00+03:00",
  dateText: "Saturday, the twenty-third of August",
  yearText: "Two thousand twenty-five",

  intro: "Together with their families",
  message: "request the pleasure of your company as they begin their forever.",

  images: {
    hero: "https://images.unsplash.com/photo-1519741497674-611481863552?w=1200&q=80&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1606216794074-735e91aa2c92?w=900&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1520854221256-17451cc331bf?w=900&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1532712938310-34cb3982ef74?w=900&q=80&auto=format&fit=crop",
    ],
  },

  events: [
    {
      label: "The Ceremony",
      place: "Saint Elias Church",
      city: "Byblos, Lebanon",
      time: "5:30 PM",
      image: "https://images.unsplash.com/photo-1438032005730-c779502df39b?w=900&q=80&auto=format&fit=crop",
      maps: "https://www.google.com/maps/search/?api=1&query=Byblos+Lebanon+church",
    },
    {
      label: "The Celebration",
      place: "The Olive Terrace",
      city: "Batroun, Lebanon",
      time: "8:00 PM",
      image: "https://images.unsplash.com/photo-1510076857177-7470076d4098?w=900&q=80&auto=format&fit=crop",
      maps: "https://www.google.com/maps/search/?api=1&query=Batroun+Lebanon",
    },
  ],

  timeline: [
    { time: "5:30 PM", title: "Holy Ceremony" },
    { time: "8:00 PM", title: "Welcome Cocktail" },
    { time: "9:00 PM", title: "Dinner & First Dance" },
    { time: "11:00 PM", title: "Cake & Party" },
  ],

  rsvpDeadline: "July 23, 2025",

  // Google Apps Script "Web app URL" (see SETUP-RSVP.md).
  // Leave empty for demos: replies are then kept only in the visitor's browser.
  rsvpEndpoint: "https://script.google.com/macros/s/AKfycbzt9jHgRlGcmLY_mOdtY2YlGCjHddUvQ_2WtxJc0y1cV2VHDfjMLwBMRbYSHDxN-YiOgg/exec",
  whatsapp: "96171143356",             // package 1 RSVP number (no + or spaces)

  music: {
    src: "https://upload.wikimedia.org/wikipedia/commons/transcoded/b/be/Clair_de_lune_%28Claude_Debussy%29_Suite_bergamasque.ogg/Clair_de_lune_%28Claude_Debussy%29_Suite_bergamasque.ogg.mp3",
    credit: "“Clair de Lune”, C. Debussy — recording via Wikimedia Commons (CC BY 3.0)",
  },

  sampleWishes: [
    { name: "Maya", text: "Wishing you a lifetime of love and laughter. Can't wait to dance with you!" },
    { name: "Uncle Fadi", text: "May your home always be filled with joy. Mabrouk in advance!" },
  ],

  brand: "Georges Azzam",
};
