# Template 01 — "Blush & Bordeaux" (wax-seal envelope)

Mobile-first digital wedding invitation. Plain HTML/CSS/JS, no build step.

## Files
| File | What it is |
|---|---|
| `config.js` | **The only file you edit per couple** — names, date, venues, photos, package, music |
| `index.html` | Page structure |
| `style.css` | Theme (colours at the top in `:root`) |
| `script.js` | Envelope animation, countdown, RSVP, wishes, package logic |

## Packages
Set `package` in `config.js` (or add `?pkg=1|2|3` to the link for demos).

| | 1 · Essential $100 | 2 · Signature $120 | 3 · Luxe $150 |
|---|---|---|---|
| Envelope opening, photos, venues + maps, timeline | ✓ | ✓ | ✓ |
| Personal guest link for every invitee | ✓ | ✓ | ✓ |
| RSVP | WhatsApp button | Form + email to couple* | Form + email to couple* |
| Background music | ✓ | ✓ | ✓ |
| Live countdown | | ✓ | ✓ |
| Wishes (in RSVP + wishes wall) | | | ✓ |

\* Email + central storage is the next step. Right now replies are saved only in the guest's browser.

## Personal guest links
```
https://your-site/lara-karim/?to=The%20Haddad%20Family&seats=3
```
- `to` – the name on the envelope and greeting
- `seats` – reserved seats (limits the "number of guests" choice)

## Run locally
Open `index.html` in a browser, or serve the folder (e.g. `npx serve .`).

## Credits / licences
- Photos: Unsplash (free licence). Replace with the couple's own photos for real clients.
- Music: "Clair de Lune" (Debussy) — Wikimedia Commons recording, CC BY 3.0 (credit shown in footer).
  Before going live, host the mp3 on your own storage instead of linking to Wikimedia.
