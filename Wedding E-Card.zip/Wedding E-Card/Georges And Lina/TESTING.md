# How to test packages 1, 2 and 3

## Open the invitation
Double-click `index.html`, or open it in Chrome.
Change the package by adding `?pkg=` to the end of the address.

| Package | Link to open |
|---|---|
| 1 · Essential $100 | `index.html?pkg=1&to=Rami&seats=2` |
| 2 · Signature $120 | `index.html?pkg=2&to=Rami&seats=2` |
| 3 · Luxe $150 | `index.html?pkg=3&to=Rami&seats=2` |

(`to` = guest name on the envelope, `seats` = seats reserved for that guest.)

---

## Package 1 — Essential ($100) checklist
- [ ] Envelope says **"For Rami"** → tap the seal → envelope opens, petals fall
- [ ] Music starts softly after tapping the seal; round button bottom-right pauses / plays it
- [ ] **No countdown**
- [ ] Greeting: "Dear Rami, we have reserved 2 seats…"
- [ ] Both venues show with photo, time, **Open location** opens Google Maps
- [ ] Timeline + 3 gallery photos
- [ ] RSVP section shows **"Confirm on WhatsApp"** → opens WhatsApp with a ready message
- [ ] **No** RSVP form, **no** wishes
- [ ] Bottom: **Signature by Georges Azzam**

## Package 2 — Signature ($120) checklist
Everything in package 1 (including music), except the WhatsApp button, **plus**:
- [ ] **Countdown** section (shows 0 because 23 Aug 2025 has passed — expected)
- [ ] RSVP **form**: name is pre-filled with "Rami"
- [ ] "Number of guests" only allows **1–2** (because `seats=2`)
- [ ] Choose "Regretfully declines" → number of guests greys out
- [ ] Send → "Thank you…" message, form locks
- [ ] **No** wish box, **no** wishes wall

## Package 3 — Luxe ($150) checklist
Everything in package 2, **plus**:
- [ ] RSVP form has **"A wish for the couple"** box
- [ ] **Wishes** section at the bottom
- [ ] Send an RSVP with a wish → your wish appears at the top of the wall

> Tip: replies in demo mode are remembered in your browser. To start clean, open the page in a private / incognito window.

---

## Testing with the real Google Sheet (packages 2 and 3)
Do this after following [SETUP-RSVP.md](SETUP-RSVP.md) and pasting the Web app URL into `config.js` → `rsvpEndpoint`.

The invitation must be **online** for this test (Netlify / GitHub Pages — next step), or opened through a local server. Opening the file by double-click may block the request.

1. Open `…?pkg=3&to=Test Guest&seats=2`
2. Send: **Joyfully accepts**, 2 guests, wish "Test wish"
3. Check:
   - [ ] **RSVPs** tab: new row with date, Test Guest, Yes, 2, 2, Test wish, ☑
   - [ ] **Summary** tab: Replies 1 · Attending 2 · Declined 0
   - [ ] Email arrives at the couple's address: "✅ New RSVP: Test Guest"
   - [ ] Reload the invitation → "Test wish" shows on the wishes wall
4. Send again as **Test Guest** with "Regretfully declines" → the same row changes to **No** (no duplicate), email says "Updated RSVP"
5. Untick **Show wish** in the sheet → reload invitation → wish disappears
6. Delete the test row before giving the sheet to the couple

---

## Accounts & credentials
There are **no credentials inside this project**, and nothing here needs a password.
You create the accounts yourself and keep the passwords in a password manager (Google Password Manager, Bitwarden…),
**never in this folder or in WhatsApp messages**.

Fill in this table for your own reference (no passwords):

| What | Value | Secret? |
|---|---|---|
| Business Gmail | `________________@gmail.com` | Password → password manager only |
| Drive folder | RSVP – Clients | — |
| Master sheet | MASTER – RSVP template | — |
| Couple sheet | Georges & Lina – RSVP → link: `__________` | Share as **Viewer** only |
| Web app URL | `https://script.google.com/macros/s/…/exec` | Not a password, but don't post it publicly |
| Couple notification emails | `__________` | Customer's private data — keep confidential |
