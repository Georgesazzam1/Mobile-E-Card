(() => {
  const C = window.INVITE;
  const qs = new URLSearchParams(location.search);
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  /* ---------- package ---------- */
  // The paid package (config.js) is the maximum: ?pkg= can only show the same or a LOWER package
  const paid = [1, 2, 3].includes(+C.package) ? +C.package : 1;
  const pkg = [1, 2, 3].includes(+qs.get("pkg")) ? Math.min(+qs.get("pkg"), paid) : paid;
  $$("[data-min-pkg]").forEach(el => { if (pkg < +el.dataset.minPkg) el.remove(); });
  $$("[data-max-pkg]").forEach(el => { if (pkg > +el.dataset.maxPkg) el.remove(); });

  /* ---------- guest personalisation: ?to=Name&seats=2 ---------- */
  const guest = (qs.get("to") || "").trim().slice(0, 60);
  const seats = Math.min(Math.max(parseInt(qs.get("seats"), 10) || 2, 1), 10);

  /* ---------- fill text ---------- */
  const fill = (attr, val) => $$(`[data-${attr}]`).forEach(el => (el.textContent = val));
  fill("monogram", C.couple.monogram);
  fill("bride", C.couple.bride);
  fill("groom", C.couple.groom);
  fill("hashtag", C.couple.hashtag);
  fill("intro", C.intro);
  fill("message", C.message);
  fill("datetext", C.dateText);
  fill("yeartext", C.yearText);
  fill("deadline", C.rsvpDeadline);
  fill("brand", C.brand);
  document.title = `${C.couple.bride} & ${C.couple.groom} — Wedding Invitation`;
  $("#heroImg").src = C.images.hero;

  if (guest) {
    $("#openingTo").textContent = `For ${guest}`;
    $("#guestName").textContent = guest;
    $("#guestSeats").textContent =
      `We have reserved ${seats} ${seats === 1 ? "seat" : "seats"} in your honour.`;
    $("#greeting").hidden = false;
  }

  /* events */
  $("#eventList").innerHTML = C.events.map(e => `
    <article class="event reveal">
      <div class="event-img"><img src="${e.image}" alt="${e.place}" loading="lazy"></div>
      <p class="label">${e.label}</p>
      <h3>${e.place}</h3>
      <p class="city">${e.city}</p>
      <p class="time">${e.time}</p>
      <a class="btn ghost" href="${e.maps}" target="_blank" rel="noopener">Open location</a>
    </article>`).join("");

  /* timeline */
  $("#timelineList").innerHTML = C.timeline.map(t =>
    `<li><span class="t">${t.time}</span><span class="dot"></span><span class="n">${t.title}</span></li>`).join("");

  /* gallery */
  $("#galGrid").innerHTML = C.images.gallery.map((src, i) =>
    `<img class="reveal" src="${src}" alt="Photo ${i + 1} of the couple" loading="lazy">`).join("");

  /* ---------- envelope opening ---------- */
  const audio = $("#bgm");
  const musicBtn = $("#musicBtn");
  if (musicBtn) audio.src = C.music.src;
  const credit = $("#musicCredit");
  if (credit) credit.textContent = "Music: " + C.music.credit;

  let opened = false;
  $("#envelope").addEventListener("click", () => {
    if (opened) return;
    opened = true;
    $("#envelope").classList.add("open");
    if (musicBtn) {
      audio.volume = 0;
      audio.play().then(() => fadeVolume(0.55, 2500)).catch(() => musicBtn.classList.add("paused"));
      musicBtn.hidden = false;
    }
    setTimeout(petals, 900);
    setTimeout(() => {
      $("#opening").classList.add("gone");
      document.body.classList.remove("locked");
      $("#invite").removeAttribute("aria-hidden");
    }, 2400);
  });

  function fadeVolume(target, ms) {
    const start = audio.volume, t0 = performance.now();
    const step = now => {
      const k = Math.min((now - t0) / ms, 1);
      audio.volume = start + (target - start) * k;
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  if (musicBtn) musicBtn.addEventListener("click", () => {
    if (audio.paused) { audio.play(); musicBtn.classList.remove("paused"); musicBtn.setAttribute("aria-label", "Pause music"); }
    else { audio.pause(); musicBtn.classList.add("paused"); musicBtn.setAttribute("aria-label", "Play music"); }
  });

  function petals() {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const box = $("#petals");
    for (let i = 0; i < 28; i++) {
      const p = document.createElement("span");
      p.className = "petal";
      p.style.left = Math.random() * 100 + "vw";
      p.style.setProperty("--drift", (Math.random() * 160 - 80) + "px");
      p.style.setProperty("--spin", (Math.random() * 720 - 360) + "deg");
      p.style.animationDuration = 4 + Math.random() * 4 + "s";
      p.style.animationDelay = Math.random() * 1.8 + "s";
      p.style.transform = `scale(${0.6 + Math.random() * 0.7})`;
      box.appendChild(p);
      p.addEventListener("animationend", () => p.remove());
    }
  }

  /* ---------- countdown ---------- */
  if ($("#cdD")) {
    const target = new Date(C.date).getTime();
    const pad = n => String(n).padStart(2, "0");
    const tick = () => {
      let d = Math.max(0, target - Date.now()) / 1000;
      const days = Math.floor(d / 86400); d -= days * 86400;
      const h = Math.floor(d / 3600); d -= h * 3600;
      const m = Math.floor(d / 60); const s = Math.floor(d - m * 60);
      $("#cdD").textContent = days; $("#cdH").textContent = pad(h);
      $("#cdM").textContent = pad(m); $("#cdS").textContent = pad(s);
    };
    tick(); setInterval(tick, 1000);
  }

  /* ---------- WhatsApp RSVP (package 1) ---------- */
  const wa = $("#waBtn");
  if (wa) {
    const text = `Hello! ${guest || "I"} would love to confirm attendance at ${C.couple.bride} & ${C.couple.groom}'s wedding.`;
    wa.href = `https://wa.me/${C.whatsapp}?text=${encodeURIComponent(text)}`;
  }

  /* ---------- RSVP form (package 2+) ---------- */
  const form = $("#rsvpForm");
  if (form) {
    $("#fGuests").innerHTML = Array.from({ length: seats }, (_, i) =>
      `<option value="${i + 1}">${i + 1}</option>`).join("");
    if (guest) $("#fName").value = guest;

    const guestsField = $(".guests-field");
    form.addEventListener("change", () => {
      const no = form.attending.value === "no";
      guestsField.style.opacity = no ? .35 : 1;
      $("#fGuests").disabled = no;
    });

    form.addEventListener("submit", async e => {
      e.preventDefault();
      const msg = $("#formMsg");
      const data = Object.fromEntries(new FormData(form));
      if (!data.name || !data.attending) { msg.textContent = "Please add your name and choose an answer."; return; }
      data.guests = data.attending === "yes" ? +(data.guests || 1) : 0;
      data.invitedSeats = seats;
      data.at = new Date().toISOString();

      const btn = form.querySelector("button");
      btn.disabled = true; btn.textContent = "Sending…";
      try {
        await saveRsvp(data);
        form.querySelectorAll("input,select,textarea,button").forEach(el => (el.disabled = true));
        btn.textContent = "Reply sent";
        msg.textContent = data.attending === "yes"
          ? "Thank you! We can't wait to celebrate with you."
          : "Thank you for letting us know. You'll be missed!";
        if (data.wish && $("#wishList")) addWish({ name: data.name, text: data.wish }, true);
      } catch {
        btn.disabled = false; btn.textContent = "Send my reply";
        msg.textContent = "Something went wrong, please try again.";
      }
    });
  }

  /* Sends the reply to the couple's Google Sheet (config.rsvpEndpoint).
     Without an endpoint (demo mode) it is kept in this browser only. */
  async function saveRsvp(data) {
    if (C.rsvpEndpoint) {
      const body = JSON.stringify(data);   // text/plain → no CORS preflight
      try {
        const res = await fetch(C.rsvpEndpoint, { method: "POST", body });
        const out = await res.json();
        if (!out.ok) throw new Error(out.error || "RSVP failed");
      } catch (err) {
        if (!(err instanceof TypeError)) throw err;
        // some browsers block reading Google's reply; send blind as a fallback
        await fetch(C.rsvpEndpoint, { method: "POST", body, mode: "no-cors" });
      }
      return;
    }
    let all = [];
    try { all = JSON.parse(localStorage.getItem("rsvps") || "[]"); } catch {}
    all.push(data);
    try { localStorage.setItem("rsvps", JSON.stringify(all)); } catch {}
    await new Promise(r => setTimeout(r, 700));
  }

  /* ---------- wishes wall (package 3) ---------- */
  function addWish(w, top) {
    const el = document.createElement("div");
    el.className = "wish";
    const p = document.createElement("p"); p.textContent = `“${w.text}”`;
    const b = document.createElement("b"); b.textContent = "— " + w.name;
    el.append(p, b);
    const list = $("#wishList");
    $("#noWish")?.remove();
    top ? list.prepend(el) : list.append(el);
  }
  if ($("#wishList")) loadWishes();
  async function loadWishes() {
    if (C.rsvpEndpoint) {
      try {
        const res = await fetch(C.rsvpEndpoint + "?action=wishes");
        const out = await res.json();
        if (out.ok && out.wishes.length) { out.wishes.forEach(w => addWish(w)); return; }
      } catch {}
      // real couple, no wishes yet → invite guests to write one (no fake samples)
      $("#wishList").innerHTML = `<p class="sub" id="noWish" style="margin:0">Be the first to leave a wish in your reply above.</p>`;
      return;
    }
    let saved = [];
    try { saved = JSON.parse(localStorage.getItem("rsvps") || "[]").filter(r => r.wish).reverse(); } catch {}
    [...saved.map(r => ({ name: r.name, text: r.wish })), ...C.sampleWishes].forEach(w => addWish(w));
  }

  /* ---------- reveal on scroll ---------- */
  const io = new IntersectionObserver(entries => entries.forEach(en => {
    if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
  }), { threshold: 0.15 });
  $$(".reveal").forEach(el => io.observe(el));
})();
