/**
 * RSVP backend for one couple — Google Apps Script
 * ------------------------------------------------
 * Paste this whole file into: Google Sheet → Extensions → Apps Script.
 * Then follow SETUP-RSVP.md (run "setup" once, then Deploy as Web app).
 */

/* ======== EDIT FOR EACH COUPLE ======== */
const SETTINGS = {
  coupleNames: "Georges & Lina",
  coupleEmails: "couple@example.com",   // one or more, separated by commas
  sendEmails: true,                     // false for the $100 package
  signature: "Signature by Georges Azzam",
};
/* ====================================== */

const RSVP_SHEET = "RSVPs";
const SUMMARY_SHEET = "Summary";
const HEADERS = ["Date", "Guest name", "Attending", "Guests", "Invited seats", "Wish", "Show wish", "Guest names"];

/** Run this ONCE from the editor: creates the tabs, headers and totals. */
function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  let sh = ss.getSheetByName(RSVP_SHEET) || ss.insertSheet(RSVP_SHEET, 0);
  sh.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS])
    .setFontWeight("bold").setBackground("#5b1f2b").setFontColor("#ffffff");
  sh.setFrozenRows(1);
  sh.setColumnWidths(1, 1, 140); sh.setColumnWidth(2, 200); sh.setColumnWidth(6, 320); sh.setColumnWidth(8, 320);

  let sum = ss.getSheetByName(SUMMARY_SHEET) || ss.insertSheet(SUMMARY_SHEET, 0);
  sum.clear();
  const r = `'${RSVP_SHEET}'`;
  sum.getRange("A1:B1").setValues([[SETTINGS.coupleNames + " — RSVP summary", ""]]).setFontWeight("bold").setFontSize(14);
  sum.getRange("A3:B6").setValues([
    ["Replies received", `=COUNTA(${r}!B2:B)`],
    ["Attending (people)", `=SUMIF(${r}!C2:C,"Yes",${r}!D2:D)`],
    ["Declined (replies)", `=COUNTIF(${r}!C2:C,"No")`],
    ["Last reply", `=IF(COUNT(${r}!A2:A)=0,"",MAX(${r}!A2:A))`],
  ]);
  sum.getRange("A3:A6").setFontWeight("bold");
  sum.getRange("B6").setNumberFormat("dd/mm/yyyy hh:mm");
  sum.setColumnWidth(1, 200); sum.setColumnWidth(2, 160);

  // remove the default empty "Sheet1" if it exists
  const def = ss.getSheetByName("Sheet1");
  if (def && ss.getSheets().length > 2) ss.deleteSheet(def);

  // triggers the Gmail permission prompt now, not on the first real RSVP
  MailApp.getRemainingDailyQuota();
}

/** Receives an RSVP from the invitation page. */
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    // Templates 1 & 2 send JSON; template 3 (book style) sends a classic form
    const d = (e.parameter && e.parameter.Username !== undefined)
      ? fromForm(e.parameter)
      : JSON.parse((e.postData && e.postData.contents) || "{}");
    const name = clean(d.name, 80);
    if (!name) return json({ ok: false, error: "missing name" });

    const attending = d.attending === "yes" ? "Yes" : "No";
    const invited = clampInt(d.invitedSeats, 1, 50, 1);
    const guests = attending === "Yes" ? clampInt(d.guests, 1, invited, 1) : 0;
    const wish = clean(d.wish, 300);
    const guestNames = clean(d.guestNames, 500);

    const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(RSVP_SHEET);
    const row = [new Date(), name, attending, guests, invited, wish, wish ? true : "", guestNames];

    // same guest replies again → update their row instead of adding a new one
    const last = sh.getLastRow();
    let target = -1;
    if (last > 1) {
      const names = sh.getRange(2, 2, last - 1, 1).getValues();
      const key = name.toLowerCase();
      for (let i = 0; i < names.length; i++) {
        if (String(names[i][0]).toLowerCase() === key) { target = i + 2; break; }
      }
    }
    const updated = target > 0;
    if (updated) sh.getRange(target, 1, 1, row.length).setValues([row]);
    else sh.appendRow(row);
    if (wish) sh.getRange(updated ? target : sh.getLastRow(), 7).insertCheckboxes().check();

    if (SETTINGS.sendEmails) notifyCouple({ name, attending, guests, invited, wish, guestNames, updated });
    return json({ ok: true, updated });
  } catch (err) {
    return json({ ok: false, error: String(err) });
  } finally {
    lock.releaseLock();
  }
}

/** Returns the wishes for the wishes wall (?action=wishes). */
function doGet(e) {
  if ((e.parameter.action || "") !== "wishes") return json({ ok: true });
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(RSVP_SHEET);
  const last = sh.getLastRow();
  if (last < 2) return json({ ok: true, wishes: [] });
  const rows = sh.getRange(2, 1, last - 1, HEADERS.length).getValues();
  const wishes = rows
    .filter(r => r[5] && r[6] === true)          // has a wish and "Show wish" is ticked
    .sort((a, b) => b[0] - a[0])
    .slice(0, 50)
    .map(r => ({ name: r[1], text: r[5] }));
  return json({ ok: true, wishes });
}

/* ---------- helpers ---------- */
function notifyCouple(r) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const icon = r.attending === "Yes" ? "✅" : "❌";
  const subject = `${icon} ${r.updated ? "Updated RSVP" : "New RSVP"}: ${r.name}`;
  const lines = r.attending === "Yes"
    ? `<b>${esc(r.name)}</b> will attend with <b>${r.guests}</b> ${r.guests === 1 ? "guest" : "guests"} (invited: ${r.invited}).`
    : `<b>${esc(r.name)}</b> regretfully cannot attend.`;
  const html = `
    <div style="font-family:Georgia,serif;max-width:480px;margin:auto;padding:24px;border:1px solid #ecd3ca;border-radius:12px;color:#3d2a2c">
      <h2 style="color:#5b1f2b;font-weight:normal;margin-top:0">${esc(SETTINGS.coupleNames)}</h2>
      <p style="font-size:17px">${lines}</p>
      ${r.guestNames ? `<p style="font-size:15px;color:#8a7372">Guests: ${esc(r.guestNames)}</p>` : ""}
      ${r.wish ? `<p style="font-style:italic;border-left:3px solid #b86f72;padding-left:12px">“${esc(r.wish)}”</p>` : ""}
      <p><a href="${ss.getUrl()}" style="color:#5b1f2b">Open your guest list</a></p>
      <p style="font-size:11px;color:#8a7372">${esc(SETTINGS.signature)}</p>
    </div>`;
  MailApp.sendEmail({ to: SETTINGS.coupleEmails, subject, htmlBody: html, name: SETTINGS.signature.replace(/^Signature by /, "") });
}

/** Converts the book-style template's form fields into the common format. */
function fromForm(p) {
  const n = parseInt(p.NumberOfInvitees, 10) || 0;
  const names = [];
  for (let i = 1; i <= 50; i++) {
    const v = (p["Invitee" + i + "_username"] || "").trim();
    if (v) names.push(v);
  }
  return {
    name: String(p.Username || "").replace(/\s*\(Not Attend\)\s*$/i, ""),
    attending: n > 0 ? "yes" : "no",
    guests: n,
    invitedSeats: parseInt(p.InvitedSeats, 10) || Math.max(n, 1),
    wish: p.Wish || "",
    guestNames: names.join(", "),
  };
}

function clean(v, max) {
  let s = String(v || "").replace(/\s+/g, " ").trim().slice(0, max);
  if (/^[=+\-@]/.test(s)) s = "'" + s;          // stop spreadsheet formula injection
  return s;
}
function clampInt(v, min, max, def) {
  const n = parseInt(v, 10);
  return isNaN(n) ? def : Math.min(Math.max(n, min), max);
}
function esc(s) {
  return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
