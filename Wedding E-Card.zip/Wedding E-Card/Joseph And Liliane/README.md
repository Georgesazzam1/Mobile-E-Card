# Template 02 — "Golden Shore" (sunrise opening)

Beach / sunset invitation. Same package system and RSVP backend as Template 01.

- **Opening:** dusk sky over the sea → tap **Open invitation** → the sun rises, the sky turns golden, the gold monogram lights up.
- **Sections:** hero photo + interlocking monogram · invitation text + countdown · personal greeting · wave-edged photo bands · The Celebration (venues + icon timeline) · swipeable arch gallery · Gift Registry · RSVP · Love Notes · "Forever starts here" closing photo.
- **Music:** "Gymnopédie No. 1" (Satie, arr. Kevin MacLeod, CC BY 3.0 — credit shown in footer).

## Per couple
Edit only `config.js` (names, initials, families, date, venues, photos, timeline icons, registry, package).
Set `registry: null` to hide the Gift Registry.

## Test
| Package | Link |
|---|---|
| 1 · $100 | `index.html?pkg=1&to=Rami&seats=2` |
| 2 · $120 | `index.html?pkg=2&to=Rami&seats=2` |
| 3 · $150 | `index.html?pkg=3&to=Rami&seats=2` |

## RSVP to Google Sheet
Each couple gets their own sheet. Follow `../Georges And Lina/SETUP-RSVP.md`,
then paste the Web app URL into `rsvpEndpoint` in `config.js`.
Until then the form works in demo mode (nothing is saved).
