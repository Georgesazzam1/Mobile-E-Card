/* ==========================================================
   TEMPLATE 02 · "GOLDEN SHORE" — edit this file for every couple
   ========================================================== */
window.INVITE = {
  /* 1 = Essential ($100) : photos, details, locations, music, WhatsApp RSVP
     2 = Signature ($120) : + RSVP form (email to couple), countdown
     3 = Luxe ($150)      : + guest wishes wall
     This is the PAID package = the maximum. ?pkg= in a link can only show
     the same or a lower package (handy for demos), never a higher one.    */
  package: 3,

  couple: {
    first: "Joseph",
    second: "Liliane",
    initials: ["J", "L"],
    hashtag: "#JosephAndLilianeForever",
  },

  families: "The Khoury and Haddad Families",
  intro: "request the honour of your presence at the wedding of their son and daughter",

  // ISO date-time in Lebanon time (UTC+3 in summer)
  date: "2027-06-12T18:00:00+03:00",
  dateText: "Saturday, June 12, 2027",

  images: {
    hero:    "https://images.unsplash.com/photo-1563196638-8c9457546e5f?w=1200&q=80&auto=format&fit=crop",
    band1:   "https://images.unsplash.com/photo-1615966650071-855b15f29ad1?w=1200&q=80&auto=format&fit=crop",
    band2:   "https://images.unsplash.com/photo-1578660692094-da697dfc1c78?w=1200&q=80&auto=format&fit=crop",
    closing: "https://images.unsplash.com/photo-1575388104683-e076ee9ccaa0?w=1200&q=80&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1554759111-8692719ccecc?w=900&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1701401942416-bea590efe2ad?w=900&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1625378986058-9d8438bc1fc6?w=900&q=80&auto=format&fit=crop",
    ],
  },

  events: [
    {
      label: "Wedding Ceremony",
      place: "Our Lady of the Sea Church",
      city: "Batroun, Lebanon",
      time: "6:00 PM",
      maps: "https://www.google.com/maps/search/?api=1&query=Our+Lady+of+the+Sea+Church+Batroun",
    },
    {
      label: "Wedding Reception",
      place: "Sunset Bay Resort",
      city: "Jbeil, Lebanon",
      time: "8:30 PM",
      maps: "https://www.google.com/maps/search/?api=1&query=Jbeil+Lebanon",
    },
  ],

  // icon: rings | glass | dinner | cake | music
  timeline: [
    { time: "6:00 PM", title: "Holy Ceremony", icon: "rings" },
    { time: "8:30 PM", title: "Sunset Cocktail", icon: "glass" },
    { time: "9:30 PM", title: "Dinner", icon: "dinner" },
    { time: "11:00 PM", title: "Cake & Dance", icon: "cake" },
  ],

  // Set to null to hide the section
  registry: {
    text: "Your love and presence are the greatest gift. For those who wish, a wedding list is available.",
    detail: "Wedding list · Account 000 000 00",
  },

  rsvpDeadline: "May 15, 2027",
  whatsapp: "96171143356",             // package 1 RSVP number (no + or spaces)

  // Google Apps Script Web app URL for this couple (see ../Georges And Lina/SETUP-RSVP.md).
  // Leave empty for demos: replies are then kept only in the visitor's browser.
  rsvpEndpoint: "https://script.google.com/macros/s/AKfycbwvtynZqEcgI_bmRuKHTgALMakSw48CumvIdyMTQSXX0rXXZyr8UwOyB9NSEPBvxm3UMA/exec",

  music: {
    src: "https://upload.wikimedia.org/wikipedia/commons/2/2a/Gymnopedie_No._1_%28ISRC_USUAN1100787%29.mp3",
    credit: "“Gymnopédie No. 1”, E. Satie — arr. & perf. Kevin MacLeod, via Wikimedia Commons (CC BY 3.0)",
  },

  sampleWishes: [
    { name: "Nadine", text: "Two beautiful souls, one beautiful journey. Wishing you endless sunsets together!" },
    { name: "Elie & Rita", text: "Mabrouk! May your love grow stronger every single day." },
  ],

  closingLine: "Forever starts here",
  brand: "Georges Azzam",
};
