(() => {
  const C = window.INVITE;
  const qs = new URLSearchParams(location.search);
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  /* ---------- package ---------- */
  // The paid package (config.js) is the maximum: ?pkg= can only show the same or a LOWER package
  const paid = [1, 2, 3].includes(+C.package) ? +C.package : 1;
  const pkg = [1, 2, 3].includes(+qs.get("pkg")) ? Math.min(+qs.get("pkg"), paid) : paid;
  $$("[data-min-pkg]").forEach(el => { if (pkg < +el.dataset.minPkg) el.remove(); });
  $$("[data-max-pkg]").forEach(el => { if (pkg > +el.dataset.maxPkg) el.remove(); });

  /* ---------- guest personalisation: ?to=Name&seats=2 ---------- */
  const guest = (qs.get("to") || "").trim().slice(0, 60);
  const seats = Math.min(Math.max(parseInt(qs.get("seats"), 10) || 2, 1), 10);

  /* ---------- fill text ---------- */
  const fill = (attr, val) => $$(`[data-${attr}]`).forEach(el => (el.textContent = val));
  fill("first", C.couple.first);
  fill("second", C.couple.second);
  fill("init1", C.couple.initials[0]);
  fill("init2", C.couple.initials[1]);
  fill("hashtag", C.couple.hashtag);
  fill("families", C.families);
  fill("intro", C.intro);
  fill("datetext", C.dateText);
  fill("deadline", C.rsvpDeadline);
  fill("closing", C.closingLine);
  fill("brand", C.brand);
  document.title = `${C.couple.first} & ${C.couple.second} — Wedding Invitation`;

  $("#heroImg").src = C.images.hero;
  $("#band1").src = C.images.band1;
  $("#band2").src = C.images.band2;
  $("#closingImg").src = C.images.closing;

  if (guest) {
    $("#openingTo").textContent = `Dear ${guest}`;
    $("#guestName").textContent = guest;
    $("#guestSeats").textContent = `${seats} ${seats === 1 ? "seat has" : "seats have"} been reserved in your honour.`;
    $("#greeting").hidden = false;
  }

  /* events */
  const pin = `<svg viewBox="0 0 24 24"><path d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6a2.5 2.5 0 0 1 0 5.5z"/></svg>`;
  $("#eventList").innerHTML = C.events.map(e => `
    <article class="event reveal">
      <p class="label">${e.label}</p>
      <h3>${e.place}</h3>
      <p class="city">${e.city}</p>
      <p class="time">${e.time}</p>
      <a class="loc" href="${e.maps}" target="_blank" rel="noopener">${pin} Location map</a>
    </article>`).join("");

  /* timeline with icons */
  const icons = {
    rings: `<svg viewBox="0 0 24 24"><circle cx="9" cy="14" r="5"/><circle cx="15" cy="14" r="5"/><path d="M10 5l2-2 2 2"/></svg>`,
    glass: `<svg viewBox="0 0 24 24"><path d="M7 3h10l-1 7a4 4 0 0 1-8 0z"/><path d="M12 14v7M8 21h8"/></svg>`,
    dinner: `<svg viewBox="0 0 24 24"><path d="M7 3v8a2 2 0 0 0 2 2v8M5 3v5M9 3v5M17 3c-2 2-2 6 0 8v10"/></svg>`,
    cake: `<svg viewBox="0 0 24 24"><path d="M4 21h16v-8H4zM4 16c2 1.5 4 1.5 6 0s4-1.5 6 0 3 1.5 4 0M12 13V9M12 6a1.5 1.5 0 0 0 1.5-1.5C13.5 3 12 2 12 2s-1.5 1-1.5 2.5A1.5 1.5 0 0 0 12 6z"/></svg>`,
    music: `<svg viewBox="0 0 24 24"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>`,
  };
  $("#timelineList").innerHTML = C.timeline.map(t =>
    `<li><span class="t">${t.time}</span><span class="ic">${icons[t.icon] || icons.rings}</span><span class="n">${t.title}</span></li>`).join("");

  /* gallery */
  $("#galStrip").innerHTML = C.images.gallery.map((src, i) =>
    `<img src="${src}" alt="Photo ${i + 1} of the couple" loading="lazy">`).join("");

  /* registry */
  if (C.registry) {
    $("#regText").textContent = C.registry.text;
    $("#regDetail").textContent = C.registry.detail || "";
  } else $("#registry").remove();

  /* ---------- sunrise opening ---------- */
  const audio = $("#bgm");
  const musicBtn = $("#musicBtn");
  if (musicBtn) audio.src = C.music.src;
  const credit = $("#musicCredit");
  if (credit) credit.textContent = "Music: " + C.music.credit;

  let opened = false;
  const open = () => {
    if (opened) return;
    opened = true;
    $("#opening").classList.add("rise");
    if (musicBtn) {
      audio.volume = 0;
      audio.play().then(() => fadeVolume(0.5, 3000)).catch(() => musicBtn.classList.add("paused"));
      musicBtn.hidden = false;
    }
    setTimeout(() => {
      $("#opening").classList.add("gone");
      document.body.classList.remove("locked");
      $("#invite").removeAttribute("aria-hidden");
    }, 2900);
  };
  $("#openBtn").addEventListener("click", open);

  function fadeVolume(target, ms) {
    const start = audio.volume, t0 = performance.now();
    const step = now => {
      const k = Math.min((now - t0) / ms, 1);
      audio.volume = start + (target - start) * k;
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }
  if (musicBtn) musicBtn.addEventListener("click", () => {
    if (audio.paused) { audio.play(); musicBtn.classList.remove("paused"); musicBtn.setAttribute("aria-label", "Pause music"); }
    else { audio.pause(); musicBtn.classList.add("paused"); musicBtn.setAttribute("aria-label", "Play music"); }
  });

  /* ---------- countdown ---------- */
  if ($("#cdD")) {
    const target = new Date(C.date).getTime();
    const pad = n => String(n).padStart(2, "0");
    const tick = () => {
      let d = Math.max(0, target - Date.now()) / 1000;
      const days = Math.floor(d / 86400); d -= days * 86400;
      const h = Math.floor(d / 3600); d -= h * 3600;
      const m = Math.floor(d / 60); const s = Math.floor(d - m * 60);
      $("#cdD").textContent = days; $("#cdH").textContent = pad(h);
      $("#cdM").textContent = pad(m); $("#cdS").textContent = pad(s);
    };
    tick(); setInterval(tick, 1000);
  }

  /* ---------- WhatsApp RSVP (package 1) ---------- */
  const wa = $("#waBtn");
  if (wa) {
    const text = `Hello! ${guest || "I"} would love to confirm attendance at ${C.couple.first} & ${C.couple.second}'s wedding.`;
    wa.href = `https://wa.me/${C.whatsapp}?text=${encodeURIComponent(text)}`;
  }

  /* ---------- RSVP form (package 2+) ---------- */
  const form = $("#rsvpForm");
  if (form) {
    $("#fGuests").innerHTML = Array.from({ length: seats }, (_, i) =>
      `<option value="${i + 1}">${i + 1}</option>`).join("");
    if (guest) $("#fName").value = guest;

    const guestsField = $(".guests-field");
    $("#fAttending").addEventListener("change", () => {
      const no = form.attending.value === "no";
      guestsField.style.opacity = no ? .35 : 1;
      $("#fGuests").disabled = no;
    });

    form.addEventListener("submit", async e => {
      e.preventDefault();
      const msg = $("#formMsg");
      const data = Object.fromEntries(new FormData(form));
      data.attending = form.attending.value;
      if (!data.name || !data.attending) { msg.textContent = "Please add your name and choose an answer."; return; }
      data.guests = data.attending === "yes" ? +(data.guests || 1) : 0;
      data.invitedSeats = seats;
      data.at = new Date().toISOString();

      const btn = form.querySelector("button");
      btn.disabled = true; btn.textContent = "Sending…";
      try {
        await saveRsvp(data);
        form.querySelectorAll("input,select,textarea,button").forEach(el => (el.disabled = true));
        btn.textContent = "Thank you";
        msg.textContent = data.attending === "yes"
          ? "Wonderful! We can't wait to celebrate with you."
          : "Thank you for letting us know. You'll be in our hearts.";
        if (data.wish && $("#wishList")) addWish({ name: data.name, text: data.wish }, true);
      } catch {
        btn.disabled = false; btn.textContent = "RSVP";
        msg.textContent = "Something went wrong, please try again.";
      }
    });
  }

  /* Sends the reply to the couple's Google Sheet (config.rsvpEndpoint).
     Without an endpoint (demo mode) it is kept in this browser only. */
  async function saveRsvp(data) {
    if (C.rsvpEndpoint) {
      const body = JSON.stringify(data);   // text/plain → no CORS preflight
      try {
        const res = await fetch(C.rsvpEndpoint, { method: "POST", body });
        const out = await res.json();
        if (!out.ok) throw new Error(out.error || "RSVP failed");
      } catch (err) {
        if (!(err instanceof TypeError)) throw err;
        await fetch(C.rsvpEndpoint, { method: "POST", body, mode: "no-cors" });
      }
      return;
    }
    let all = [];
    try { all = JSON.parse(localStorage.getItem("rsvps-shore") || "[]"); } catch {}
    all.push(data);
    try { localStorage.setItem("rsvps-shore", JSON.stringify(all)); } catch {}
    await new Promise(r => setTimeout(r, 700));
  }

  /* ---------- wishes wall (package 3) ---------- */
  function addWish(w, top) {
    const el = document.createElement("div");
    el.className = "wish";
    const p = document.createElement("p"); p.textContent = `“${w.text}”`;
    const b = document.createElement("b"); b.textContent = w.name;
    el.append(p, b);
    const list = $("#wishList");
    $("#noWish")?.remove();
    top ? list.prepend(el) : list.append(el);
  }
  if ($("#wishList")) loadWishes();
  async function loadWishes() {
    if (C.rsvpEndpoint) {
      try {
        const res = await fetch(C.rsvpEndpoint + "?action=wishes");
        const out = await res.json();
        if (out.ok && out.wishes.length) { out.wishes.forEach(w => addWish(w)); return; }
      } catch {}
      $("#wishList").innerHTML = `<p class="sub" id="noWish" style="margin:0">Be the first to leave a love note in your reply above.</p>`;
      return;
    }
    let saved = [];
    try { saved = JSON.parse(localStorage.getItem("rsvps-shore") || "[]").filter(r => r.wish).reverse(); } catch {}
    [...saved.map(r => ({ name: r.name, text: r.wish })), ...C.sampleWishes].forEach(w => addWish(w));
  }

  /* ---------- reveal on scroll ---------- */
  const io = new IntersectionObserver(entries => entries.forEach(en => {
    if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
  }), { threshold: 0.15 });
  $$(".reveal").forEach(el => io.observe(el));
})();
