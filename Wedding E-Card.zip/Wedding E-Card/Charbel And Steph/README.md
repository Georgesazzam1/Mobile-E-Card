# Template 03 — "Charbel & Steph" (book style)

Black splash → round photo "Tap to open" → fireworks + music → 7 pages that flip like a book
(swipe, arrows or NEXT/BACK).

| Page | Content | Photo |
|---|---|---|
| 1 | Round photo, tap to open | `img/1.jpeg` background, `img/4.jpeg` round |
| 2 | "Are getting married" + verse | `img/2.jpeg` |
| 3 | Save the date + families | `img/3.jpeg` |
| 4 | Ceremony + map | `img/5.jpeg` |
| 5 | Reception + map | `img/6.jpeg` |
| 6 | Gift registry | `img/7.jpeg` |
| 7 | RSVP with every guest's name | `img/8.jpeg` |

Music: `WeddingInvitation.mp3`.

## Packages
Set `var PACKAGE=3;` near the bottom of `index.html` (or add `&pkg=1|2|3` to the link for demos).

| | 1 · Essential $100 | 2 · Signature $120 | 3 · Luxe $150 |
|---|---|---|---|
| Book pages, photos, venues + maps, music | ✓ | ✓ | ✓ |
| RSVP | WhatsApp button (`WHATSAPP` number) | Form → Google Sheet + email | Form → Google Sheet + email |
| Countdown on "Save the date" | | ✓ | ✓ |
| Wish box in RSVP + **Wishes** page (page 8) | | | ✓ |

Test links:
- `index.html?np=3&pkg=1`
- `index.html?np=3&pkg=2`
- `index.html?np=3&pkg=3`

## Guest links
This template uses `?np=` for the number of invitees:
```
https://your-site/charbel-steph/?np=3
```
The guest chooses how many are coming (up to `np`) and types each person's name.

## RSVP
Replies go to the **Charbel & Steph – RSVP** Google Sheet in the business account
(`GOOGLE_SCRIPT` near the bottom of `index.html`). The sheet shows
Date · Guest name · Attending · Guests · Invited seats · **Guest names**, and an email is sent for every reply.

## For a new couple
Edit the texts in `index.html` (names, date, families, venues, map links, registry, RSVP date),
replace the photos in `img/` with the same file names, and set up a new sheet
(see `../Georges And Lina/SETUP-RSVP.md`).
