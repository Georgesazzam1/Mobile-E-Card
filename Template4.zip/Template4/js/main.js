(function ($) {
"use strict";
$(window).scroll(function () {
    if ($(this).scrollTop() > 300) {
        $('.back-to-top').fadeIn('slow');
    } else {
        $('.back-to-top').fadeOut('slow');
    }
    });
$('.back-to-top').click(function () {
	$('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
	return false;
}); 
})(jQuery);

document.getElementById('startMusicBtn').addEventListener('click', function() {
	var music = document.getElementById('weddingMusic');
	music.play();
	var myCarousel = new bootstrap.Carousel(document.getElementById('carouselId'), {
		interval: false
	});
	myCarousel.next();
});
var countDownDate = new Date("Aug 23, 2025 18:00:00").getTime();
var x = setInterval(function() 
{
	var now = new Date().getTime();
	var distance = countDownDate - now;
	var days = Math.floor(distance / (1000 * 60 * 60 * 24));
	var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
	var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
	var seconds = Math.floor((distance % (1000 * 60)) / 1000);

	  if (distance >= 0) 
		{
			document.getElementById("countdown").innerHTML = `
			  <div class="time-unit">
				${days} <div class="time-label">Days</div>
			  </div>
			  <div class="time-unit">
				${hours} <div class="time-label">Hours</div>
			  </div>
			  <div class="time-unit">
				${minutes} <div class="time-label">Minutes</div>
			  </div>
			  <div class="time-unit">
				${seconds}<div class="time-label">Seconds</div>
			  </div>
			`;
		} 
		else 
		{
			clearInterval(x);
			document.getElementById("countdown").innerHTML = '';
			document.getElementById("message").innerHTML = '<span class="expired">EXPIRED</span>';
		}
}, 1000);
				
const attendingButton = document.getElementById('attending');
const notAttendingButton = document.getElementById('not-attending');
const attendingSection = document.querySelector('.attending-section');
const notAttendingSection = document.querySelector('.not-attending-section');
attendingButton.addEventListener('click', function () {
	attendingButton.classList.add('selected');
	notAttendingButton.classList.remove('selected');
	attendingSection.style.display = 'block';
	notAttendingSection.style.display = 'none';

	// Clear and disable non-attending input
	const nameInput = document.getElementById('name');
	nameInput.value = "";
	nameInput.removeAttribute('required');

	// Set all guest inputs as required
	for (let i = 1; i <= np; i++) {
		let guestInput = document.getElementById('guest' + i);
		if (guestInput) {
			guestInput.setAttribute('required', 'required');
			guestInput.value = "";
		}
	}
	
	// Reflect np properly
	document.getElementById('invite-count').textContent = np.toString();
	document.getElementById('guest-count').value = np.toString();
});

notAttendingButton.addEventListener('click', function() {
	notAttendingButton.classList.add('selected');
	attendingButton.classList.remove('selected');
	attendingSection.style.display = 'none';
	notAttendingSection.style.display = 'block';

	let guestCount = parseInt(document.getElementById('guest-count').value);
	for (let i = 1; i <= guestCount; i++) {
		let guestInput = document.getElementById('guest' + i);
		if (guestInput) {
			guestInput.value = "";
			guestInput.removeAttribute('required');
		}
	}

	document.getElementById('name').value = "";
	document.getElementById('name').setAttribute('required', 'required');
});

attendingSection.style.display = 'block';
notAttendingSection.style.display = 'none';		
		
document.getElementById('guest-count').addEventListener('change', function() {
	document.getElementById('invite-count').textContent = this.value;
});
	
document.getElementById('guest-count').addEventListener('change', function() {
	let guestCount = parseInt(this.value);
	document.getElementById('invite-count').textContent = guestCount;

	let guestListDiv = document.getElementById('guest-list');
	guestListDiv.innerHTML = "";

	for (let i = 1; i <= guestCount; i++) {
		let guestDiv = document.createElement("div");
		guestDiv.classList.add("guest-name");

		let label = document.createElement("label");
		label.setAttribute("for", "guest" + i);
		label.textContent = `Guest #${i}`;

		let input = document.createElement("input");
		input.setAttribute("type", "text");
		input.setAttribute("id", "guest" + i);
		input.setAttribute("class", "input-field");
		input.setAttribute("placeholder", "Enter guest name");

		guestDiv.appendChild(label);
		guestDiv.appendChild(input);
		guestListDiv.appendChild(guestDiv);
	}
});


function showPopup() {
	//	debugger;
	let condition = true; // Change this condition as needed
	if (condition) {
		document.getElementById("popup").style.display = "block";
		document.getElementById("overlay").style.display = "block";
	}
}
function hidePopup() {
	document.getElementById("popup").style.display = "none";
	document.getElementById("overlay").style.display = "none";
}
	
document.addEventListener('DOMContentLoaded', function() {
    var myCarousel = new bootstrap.Carousel(document.getElementById('carouselId'), {
        interval: false,
        touch: false
    });
    function checkIfSeventhSlide() {
        var carouselItems = document.querySelectorAll('.carousel-item');
        var seventhSlide = document.getElementById('seventh-slide');
        if (seventhSlide.classList.contains('active')) {
            triggerSeventhSlideMethod();
        }
    }

    function triggerSeventhSlideMethod() {
		//debugger;
        myCarousel.to(7);
        myCarousel._config.touch = false; // Disable swipe on all slides
    }

    myCarousel._element.addEventListener('slid.bs.carousel', function() {
        checkIfSeventhSlide();
    });
    checkIfSeventhSlide();
});




//Send Email
function sendMailN() {
	var params = {
		name: document.getElementById("name").value,
		email: "georges.azzam@hotmail.com",
		attendee_count: 0,
		guests: "No Guest"
	};
	const serviceID = "service_xv0tyrb";
	const templateID = "template_ukt1gta";
	emailjs.send(serviceID, templateID, params)
		.then(res => {
			document.getElementById("guest-count").value = "";
			console.log(res);
			showPopup();
		})
		.catch(err => console.log(err));
}



//Add To Attendance Sheet:

document.getElementById('guest-count').addEventListener('change', function() {
    let guestCount = parseInt(this.value);
    document.getElementById('invite-count').textContent = guestCount;

    let guestListDiv = document.getElementById('guest-list');
    guestListDiv.innerHTML = ""; // Clear previous guests

    for (let i = 1; i <= guestCount; i++) {
        let guestDiv = document.createElement("div");
        guestDiv.classList.add("guest-name");

        let label = document.createElement("label");
        label.setAttribute("for", "guest" + i);
        label.textContent = `Guest #${i}`;

        let input = document.createElement("input");
        input.setAttribute("type", "text");
        input.setAttribute("id", "guest" + i);
        input.setAttribute("name", `Invitee${i}_username`); // <-- Add this line
        input.setAttribute("class", "input-field");
        input.setAttribute("placeholder", "Enter guest name");

        guestDiv.appendChild(label);
        guestDiv.appendChild(input);
        guestListDiv.appendChild(guestDiv);
    }
});

/*
 function sendData(event) {
	 
	 let guestCount = parseInt(document.getElementById("guest-count").value);
		let guestNames = [];
		debugger;
		for (let i = 1; i <= guestCount; i++) {
			let guestInput = document.getElementById("guest" + i);
			if (guestInput) {
				guestNames.push(guestInput.value);
			}
		}


		var params = {
			email: "georges.azzam@hotmail.com",
			attendee_count: guestCount,
			guests: guestNames.join("\n") // Use newline (\n) for better formatting
		};

		const serviceID = "service_xv0tyrb";
		const templateID = "template_ukt1gta";

		emailjs.send(serviceID, templateID, params)
			.then(res => {
				document.getElementById("guest-count").value = "";
				console.log(res);
				showPopup();
			})
			.catch(err => console.log(err));
			
			
			 event.preventDefault(); // Prevent default form submission

		const form = document.getElementById("contactForm");
		const formData = new FormData(form);

		// Check which section was used to submit
		const isAttending = event.submitter.closest(".attending-section") !== null;

		if (!isAttending) {
			// If "Not Attending", ensure NumberOfInvitees is 0
			formData.set("NumberOfInvitees", "0");

			// Ensure the name is included
			const nameField = document.getElementById("name");
			if (nameField) {
				formData.set("Username", nameField.value);
			}
		}

		fetch(form.action, {
			method: "POST",
			body: formData
		})
		.then(response => response.json())
		.then(data => {
			if (data.result === "success") {
			   // alert("Form submitted successfully!");
			} else {
				alert("Error: " + data.error);
			}
		})
		.catch(error => alert("Request failed: " + error));

		return false;
}
	*/
	
	
	function sendData(event) {
  event.preventDefault(); // Prevent default form submission

  const guestCount = parseInt(document.getElementById("guest-count").value);
  let guestNames = [];

  // Determine if attending or not by checking selected button
  const attendingBtn = document.getElementById('attending');
  const isAttending = attendingBtn.classList.contains('selected');

  // Validation
  if (isAttending) {
    for (let i = 1; i <= guestCount; i++) {
      let guestInput = document.getElementById("guest" + i);
      if (!guestInput || guestInput.value.trim() === "") {
        alert(`Please enter the name for Guest #${i}`);
        guestInput.focus();
        return false;
      }
      guestNames.push(guestInput.value.trim());
    }
  } else {
    const nameField = document.getElementById("name");
    if (!nameField.value.trim()) {
      alert("Please enter your name");
      nameField.focus();
      return false;
    }
  }

  // Prepare emailJS params
  const params = {
    email: "georges.azzam@hotmail.com",
    attendee_count: isAttending ? guestCount : 0,
    guests: isAttending ? guestNames.join("\n") : "",
    Username: !isAttending ? document.getElementById("name").value.trim() : ""
  };

  const serviceID = "service_xv0tyrb";
  const templateID = "template_ukt1gta";

  // Disable form inputs & buttons during submission
  const form = document.getElementById("contactForm");
  const attendeesClassDiv = document.querySelector('.attendees-class');
  const buttonsDiv = attendeesClassDiv.querySelector('.buttons');
  const attendingSection = attendeesClassDiv.querySelector('.attending-section');
  const notAttendingSection = attendeesClassDiv.querySelector('.not-attending-section');
  const replyDate = attendeesClassDiv.querySelector('.reply-date');
  const inviteCount = attendeesClassDiv.querySelector('.invite-count');

  // Show loading message and hide others
  document.getElementById('loading-message').style.display = 'block';
  document.getElementById('success-attending-message').style.display = 'none';
  document.getElementById('success-not-attending-message').style.display = 'none';

  // Disable form and buttons visually
  form.style.display = 'none';
  buttonsDiv.style.display = 'none';
  replyDate.style.display = 'none';
  inviteCount.style.display = 'none';
  attendingSection.style.display = 'none';
  notAttendingSection.style.display = 'none';

  // Send email via EmailJS
  emailjs.send(serviceID, templateID, params)
    .then(res => {
      console.log('EmailJS response:', res);
      // Then send form data to your Google script (or other backend)
      const formData = new FormData(form);

      // Adjust formData for not attending
      if (!isAttending) {
        formData.set("NumberOfInvitees", "0");
        formData.set("Username", document.getElementById("name").value.trim());
      }

      return fetch(form.action, {
        method: "POST",
        body: formData
      });
    })
    .then(response => response.json())
    .then(data => {
      if (data.result === "success") {
        // After successful submission, simulate loading for 3 seconds
        setTimeout(() => {
          document.getElementById('loading-message').style.display = 'none';

          // Show correct success message
          if (isAttending) {
            document.getElementById('success-attending-message').style.display = 'block';
          } else {
            document.getElementById('success-not-attending-message').style.display = 'block';
          }
        }, 3000);
      } else {
        alert("Error: " + data.error);
        // If error, show form and buttons again
        form.style.display = 'block';
        buttonsDiv.style.display = 'flex';
        replyDate.style.display = 'block';
        inviteCount.style.display = 'block';
        if (isAttending) attendingSection.style.display = 'block';
        else notAttendingSection.style.display = 'block';
        document.getElementById('loading-message').style.display = 'none';
      }
    })
    .catch(error => {
      alert("Request failed: " + error);
      // On failure, restore UI
      form.style.display = 'block';
      buttonsDiv.style.display = 'flex';
      replyDate.style.display = 'block';
      inviteCount.style.display = 'block';
      if (isAttending) attendingSection.style.display = 'block';
      else notAttendingSection.style.display = 'block';
      document.getElementById('loading-message').style.display = 'none';
    });

  return false;
}
	
	
	
	
	
	
	
	